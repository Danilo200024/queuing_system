import RPi.GPIO as GPIO
import time
import django

# Call django.setup() only once when this module is run directly.
if __name__ == "__main__":
    import sys
    import os
    sys.path.append('/home/pi/queuing_system')
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'queuing_system.settings')
    django.setup()

    from print_ticket import print_ticket

    # Define button pins for each window
    button_pins = {
        'Cashier': 17,
        'Registrar': 27,
        'Assessment 1': 22,
        'Assessment 2': 5, 
        'Assessment 3': 6,
    }

    # Set GPIO mode and pin setup
    GPIO.setmode(GPIO.BCM)
    for pin in button_pins.values():
        GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    try:
        while True:
            for window_name, pin in button_pins.items():
                if GPIO.input(pin) == GPIO.LOW:
                    print_ticket(window_name)
                    time.sleep(0.5)
    except KeyboardInterrupt:
        GPIO.cleanup()
