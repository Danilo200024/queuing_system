import RPi.GPIO as GPIO
import serial
import time
import os
import django
import sys

# Append project directory to sys.path and set up Django environment
sys.path.append('/home/pi/queuing_system')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'queuing_system.settings')

django.setup()

from transactions.models import Transactions
from users.models import WindowList
from django.utils import timezone

# Set up the buzzer pin
buzzer_pin = 23

GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer_pin, GPIO.OUT)

# Configure the serial printer
printer = serial.Serial('/dev/serial0', baudrate=19200, timeout=1)

def sound_buzzer():
    """
    Sound the buzzer for 0.5 seconds.
    """
    GPIO.output(buzzer_pin, GPIO.HIGH)
    time.sleep(0.5)
    GPIO.output(buzzer_pin, GPIO.LOW)

def generate_queue_number(queue_type):
    """
    Generate the next queue number based on the queue type (e.g., Cashier, Registrar, Assessment).
    """
    today = timezone.now().date()
    last_transaction = Transactions.objects.filter(window__name=queue_type, created_at__date=today).order_by('-id').first()
    if last_transaction:
        try:
            last_number = int(last_transaction.queue_number.split('-')[-1])
            return f"{queue_type[:3].upper()}-{last_number + 1:03d}"
        except ValueError:
            return f"{queue_type[:3].upper()}-001"
    return f"{queue_type[:3].upper()}-001"

def print_ticket(window_name):
    """
    Generate a queue number, save the transaction to the database, and print the ticket.
    """
    try:
        # Generate the queue number based on the window name
        queue_number = generate_queue_number(window_name.split(" ")[0])
        
        # Determine the window number based on window_name (improved logic)
        window_num = 0
        if "assessment" in window_name.lower():
            if "1" in window_name.lower():
                window_num = 2
            elif "2" in window_name.lower():
                window_num = 4
            elif "3" in window_name.lower():
                window_num = 6

        # Get the WindowList object
        window = WindowList.objects.get(name=window_name.split(" ")[0])
        
        # Create the transaction in the database
        transaction = Transactions.objects.create(
            window=window,
            queue_number=queue_number,
            status=0,
            window_num=window_num,  # Use the derived window number
        )

        # Initialize the printer
        printer.write(b'\x1B\x40')  # Initialize the printer

        # Print the title (centered and large font)
        printer.write(b'\x1B\x61\x01')  # Center alignment
        printer.write(b'\x1B\x45\x01')
        printer.write(b"SAINT FRANCIS XAVIER COLLEGE\n")
        printer.write(b'\x1B\x45\x00')

        # Print the subheading (centered)
        printer.write(b'\x1B\x61\x01')  # Center alignment
        printer.write(f"{window_name}\n".encode())
        printer.write(b'\x1B\x61\x00')  # Reset alignment to left

        # Print the queue number (centered and large font)
        printer.write(b'\x1B\x61\x01')  # Center alignment
        printer.write(b'\x1B\x21\x30')  # Set font size to large
        printer.write(f"{queue_number}\n".encode())
        printer.write(b'\x1B\x21\x00')  # Reset to normal font size

        # Print the date (left-aligned)
        printer.write(b'\x1B\x61\x00')  # Reset alignment to left
        printer.write(f"Date: {transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')}\n".encode())

        # Add extra space after details
        printer.write(b"\n")  # Add extra space
        printer.write(b"\n")  # Add extra space
        printer.write(b"\n")  # Add extra space

        # Feed and cut the paper
        printer.write(b'\x1D\x56\x00')  # Feed and cut the paper
        printer.flush()



        # Sound the buzzer
        sound_buzzer()

        print(f"Ticket printed for {window_name}: {queue_number}")

    except WindowList.DoesNotExist:
        print(f"Error: Invalid window name '{window_name}'.")
    except Exception as e:
        print(f"Error printing ticket: {e}")
