from django.shortcuts import render
from django.contrib.auth import logout
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.decorators import login_required
from .decorators import role_required
from .models import User, Staff, WindowList

@role_required('ADMIN')
def add_user(request):
    if request.method == 'POST':
        name        = request.POST['name']
        email       = request.POST['email']
        password    = request.POST['password']
        window_id   = request.POST['user_window']
        window_num  = request.POST['window_number']
        user_type   = request.POST['user_type']
        
        if not name:
            return JsonResponse({'success': False, 'error': 'Name is required'})
        if not email:
            return JsonResponse({'success': False, 'error': 'Email is required'})
        if not password:
            return JsonResponse({'success': False, 'error': 'Password is required'})
        if not user_type:
            return JsonResponse({'success': False, 'error': 'User type is required'})

        try:
            window = None
            if window_id:
                try:
                    window = WindowList.objects.get(id=window_id)
                except ObjectDoesNotExist:
                    return JsonResponse({'success': False, 'error': 'Invalid window ID'})

            if user_type == '1':
                user = User.objects.create_superuser(email=email, password=password, name=name)
            elif user_type == '2':
                if not window or not window_num:
                    return JsonResponse({'success': False, 'error': 'Window and window number are required for staff'})
                user = Staff.staff.create_user(email=email, password=password, name=name, window=window, window_num=window_num)
            else:
                return JsonResponse({'success': False, 'error': 'Invalid user type'})

            user_data = model_to_dict(user, fields=['id', 'name', 'email', 'role', 'date_joined'])
            return JsonResponse({'success': True, 'user': user_data})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

def get_user_info(request):
    try:
        id = request.GET.get('id')
        user = User.objects.get(id=id)
        user_data = model_to_dict(user, fields=['id', 'name', 'email', 'role', 'date_joined', 'window', 'window_num'])
        return JsonResponse({'success': True, 'user': user_data})
    except ObjectDoesNotExist:
        return JsonResponse({'success': False, 'error': 'User not found'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@role_required('ADMIN')
def update_user(request):
    if request.method == 'POST':
        user_id          = request.POST.get('id')
        name        = request.POST.get('name')
        email       = request.POST.get('email')
        password    = request.POST.get('password', None)
        window_id   = request.POST.get('user_window')
        window_num  = request.POST.get('window_number')

        if not user_id:
            return JsonResponse({'success': False, 'error': 'User ID is required'})
        if not name:
            return JsonResponse({'success': False, 'error': 'Name is required'})
        if not email:
            return JsonResponse({'success': False, 'error': 'Email is required'})

        user = User.objects.get(id=user_id)
        if user:
            try:
                user.name = name
                user.email = email
                if password:
                    user.set_password(password)
                
                if user.role == 'STAFF':
                    if window_id:
                        try:
                            window = WindowList.objects.get(id=window_id)
                            user.window = window
                        except ObjectDoesNotExist:
                            return JsonResponse({'success': False, 'error': 'Invalid window ID'})
                    if window_num:
                        user.window_num = window_num

                user.save()
                user_data = model_to_dict(user, fields=['id', 'name', 'email', 'role', 'window', 'window_num', 'date_joined'])
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({'success': False, 'error': str(e)})
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

@role_required('ADMIN')
def delete_user(request):
    try:
        id = request.GET.get('id')
        staff = Staff.staff.get(id=id)
        staff.delete()
        return JsonResponse({'success': True, 'message': 'User deleted successfully'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@role_required('ADMIN')
def admin_profile(request):
    return render(request, 'admin/modules/profile.html', {})

@login_required(login_url='/')
def update_user_info(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        if not name:
            return JsonResponse({'success': False, 'error': 'Name is required'})
        if not email:
            return JsonResponse({'success': False, 'error': 'Email is required'})

        user = request.user
        try:
            user.name = name
            user.email = email
            user.save()
            return JsonResponse({'success': True, 'message': 'User information updated successfully'})
        except ObjectDoesNotExist:
            return JsonResponse({'success': False, 'error': 'User not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/')
def update_password(request):
    if request.method == 'POST':
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if not current_password or not new_password or not confirm_password:
            return JsonResponse({'success': False, 'error': 'All password fields are required'})
        if new_password != confirm_password:
            return JsonResponse({'success': False, 'error': 'New passwords do not match'})
        user = request.user
        try:
            if not user.check_password(current_password):
                return JsonResponse({'success': False, 'error': 'Current password is incorrect'})
            user.set_password(new_password)
            user.save()
            return JsonResponse({'success': True, 'message': 'Password updated successfully'})
        except ObjectDoesNotExist:
            return JsonResponse({'success': False, 'error': 'User not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required(login_url='/')
def delete_account(request):
    if request.method == 'POST':
        user = request.user
        try:
            logout(request)
            user.delete()
            return JsonResponse({'success': True, 'message': 'User account deleted successfully'})
        except ObjectDoesNotExist:
            return JsonResponse({'success': False, 'error': 'User not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})
