from django.shortcuts import redirect
from functools import wraps
from django.http import HttpResponseForbidden

def redirect_if_authenticated(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect_role_based(request.user)
        return view_func(request, *args, **kwargs)
    return _wrapped_view

def role_required(role):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            if request.user.is_authenticated:
                if request.user.role == role:
                    return view_func(request, *args, **kwargs)
                else:
                    return redirect_role_based(request.user)
            return redirect('login')
        return _wrapped_view
    return decorator

def redirect_role_based(user):
    if user.role == 'ADMIN':
        return redirect('admin_dashboard')
    elif user.role == 'STAFF':
        return redirect('staff_dashboard')
    else:
        return HttpResponseForbidden("Unauthorized access")
