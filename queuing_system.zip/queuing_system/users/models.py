from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager

# Create your models here.
class WindowList(models.Model):
    name            = models.CharField(max_length=100)
    created_at      = models.DateTimeField(auto_now=True)
    updated_at      = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'window_list'

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password, name, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        if not password:
            raise ValueError("The Password field must be set")
        
        email = self.normalize_email(email)
        user = self.model(email=email, name=name, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, name, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(email, password, name, **extra_fields)

class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN           = 'ADMIN', 'Admin'
        STAFF           = 'STAFF', 'Staff'

    objects = CustomUserManager()

    base_role           = Role.ADMIN
    name                = models.CharField(max_length=200)
    email               = models.EmailField(max_length=100, unique=True)
    password            = models.CharField(max_length=200)
    USERNAME_FIELD      = 'email'
    REQUIRED_FIELDS     = []
    username            = None
    first_name          = None
    last_name           = None
    role                = models.CharField(max_length=50, choices=Role.choices)
    window              = models.ForeignKey(WindowList, on_delete=models.CASCADE, null=True, blank=True)
    window_num          = models.SmallIntegerField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.role = self.base_role
        super().save(*args, **kwargs)

class StaffManager(BaseUserManager):
    def create_user(self, email, password, name, window, window_num):
        if not email:
            raise ValueError("User must have an email address")
        if not password:
            raise ValueError("User must have a password")

        user = self.model(
            email=self.normalize_email(email),
            name=name,
            window=window,
            window_num=window_num
        )
        user.set_password(password)
        user.save()
        return user
    
    def get_queryset(self, *args, **kwargs):
        results = super().get_queryset(*args, **kwargs)
        return results.filter(role=User.Role.STAFF)

class Staff(User):
    base_role = User.Role.STAFF
    staff = StaffManager()
    class Meta:
        proxy = True