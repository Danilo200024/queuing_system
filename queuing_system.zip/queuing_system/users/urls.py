from django.urls import path
from django.contrib.auth.views import LogoutView
from .views import *

urlpatterns = [
    path('admin/users/add/', add_user, name='add_user'),
    path('admin/users/info/', get_user_info, name='get_user_info'),
    path('admin/users/update/', update_user, name='update_user'),
    path('admin/users/delete/', delete_user, name='delete_user'),

    path('user/profile/update/', update_user_info, name='update_profile'),
    path('user/profile/change_password/', update_password, name='change_password'),
    path('user/profile/delete/', delete_account, name='delete_account'),

    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
]