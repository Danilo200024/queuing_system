from django.http import JsonResponse
from django.utils.timezone import now
from django.db.models import Count
from django.db.models.functions import TruncDate, TruncDay
from .models import Transactions
from users.models import WindowList
from users.decorators import role_required
from datetime import timedelta, datetime

from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

def generate_queue_number(queue_type):
    """
    Generate the next queue number based on the queue type (e.g., Cashier, Registrar, Assessment).
    This could use existing transactions or a predefined pattern.
    """
    today = now().date()
    last_transaction = Transactions.objects.filter(window__name=queue_type, created_at__date=today).order_by('-id').first()
    if last_transaction:
        try:
            last_number = int(last_transaction.queue_number.split('-')[-1])
            return f"{queue_type[:3].upper()}-{last_number + 1:03d}"
        except ValueError:
            return f"{queue_type[:3].upper()}-001"
    return f"{queue_type[:3].upper()}-001"

def add_queue(request):
    if request.method == 'POST':
        try:
            window_id = request.POST.get('window_id')
            status = request.POST.get('status', 0)
            window_num = request.POST.get('window_num', 0)
            
            try:
                window = WindowList.objects.get(id=window_id)
            except WindowList.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'Invalid window or queue type'})

            queue_number = generate_queue_number(window.name)

            transaction = Transactions.objects.create(
                window=window,
                queue_number=queue_number,
                status=status,
                window_num=window_num
            )

            return JsonResponse({'success': True, 'transaction': {
                'id': transaction.id,
                'queue_number': transaction.queue_number,
                'status': transaction.status,
                'window_num': transaction.window_num,
                'created_at': transaction.created_at,
            }})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@role_required("STAFF")
def next_serve(request):
    try:
        if not request.user.window_id:
            return JsonResponse({'success': False, 'error': 'User is not assigned to any window.'})

        window = WindowList.objects.get(id=request.user.window_id)
        windows = WindowList.objects.exclude(id=request.user.window_id)
        windows_data = [{'id': w.id, 'name': w.name} for w in windows]

        current_transaction = Transactions.objects.filter(
            window=window,
            window_num=request.user.window_num,
            status=1
        ).order_by('created_at').first()
        if current_transaction:
            current_transaction.status = 2
            current_transaction.save()

        if window.name.lower() == "assessment":
            window_num = request.user.window_num
        else:
            window_num = 0

        next_transaction = Transactions.objects.filter(
            window=window,
            window_num=window_num,
            status=0
        ).order_by('created_at').first()
        channel_layer = get_channel_layer()
        if next_transaction:
            next_transaction.status = 1
            if next_transaction.window_num == 0:
                next_transaction.window_num = request.user.window_num
            next_transaction.save()

            async_to_sync(channel_layer.group_send)(
                "queues",
                {
                    "type": "send_queue_update",
                    "data": {
                        f"{window.name}-{next_transaction.window_num}": next_transaction.queue_number,
                    }
                }
            )

            return JsonResponse({'success': True, 'next_serve': {
                'id': next_transaction.id,
                'queue_number': next_transaction.queue_number,
                'status': next_transaction.status,
                'window_num': next_transaction.window_num,
                'created_at': next_transaction.created_at,
            }, 'windows' : windows_data})

        async_to_sync(channel_layer.group_send)(
                "queues",
                {
                    "type": "send_queue_update",
                    "data": {
                        f"{window.name}-{request.user.window_num}": "",
                    }
                }
            )

        return JsonResponse({'success': True, 'message': 'No more transactions in the queue.', 'windows' : windows_data})

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@role_required("STAFF")
def cancel_queue(request):
    if request.method == 'POST':
        try:
            transaction_id = request.POST.get('transaction_id')

            transaction = Transactions.objects.get(id=transaction_id)
            if not transaction:
                return JsonResponse({'success': False, 'error': 'Transaction not found.'})

            transaction.status = -1 
            transaction.save()
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "queues",
                {
                    "type": "send_queue_update",
                    "data": {f"{transaction.window.name}-{transaction.window_num}": ""}
                }
            )

            return JsonResponse({
                'success': True,
                'message': f"Queue {transaction.queue_number} has been cancelled successfully."
            })

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method.'})


@role_required("STAFF")
def transfer_queue(request):
    if request.method == 'POST':
        try:
            transaction_id = request.POST.get('transaction_id')
            target_window_id = request.POST.get('target_window_id')

            transaction = Transactions.objects.get(id=transaction_id)
            if not transaction:
                return JsonResponse({'success': False, 'error': 'Transaction not found'})
            current_window = WindowList.objects.get(id=transaction.window_id)
            target_window = WindowList.objects.get(id=target_window_id)
            if not target_window:
                return JsonResponse({'success': False, 'error': 'Target window not found'})

            if target_window.name.lower() == "assessment":
                window_counts = Transactions.objects.filter(
                    window=target_window,
                    status=0
                ).values('window_num').annotate(count=Count('id')).order_by('count')

                window_num = window_counts[0]['window_num'] if window_counts else 1
            else:
                window_num = 0

            latest_transaction = Transactions.objects.filter(
                window=target_window
            ).order_by('-created_at').first()

            transaction.window = target_window
            transaction.status = 0
            transaction.window_num = window_num
            
            if latest_transaction:
                transaction.created_at = latest_transaction.created_at + timedelta(seconds=1)
            else:
                transaction.created_at = now()
            
            transaction.save()
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "queues",
                {
                    "type": "send_queue_update",
                    "data": {
                        f"{current_window.name}-{request.user.window_num}": "",
                    }
                }
            )

            return JsonResponse({
                'success': True,
                'message': f"Queue {transaction.queue_number} transferred to {target_window.name}.",
                'transaction': {
                    'id': transaction.id,
                    'queue_number': transaction.queue_number,
                    'window': target_window.name,
                    'status': transaction.status,
                }
            })

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@role_required("ADMIN")
def get_weekly_queues(request):
    try:
        today = datetime.now().date()
        start_of_week = today - timedelta(days=today.weekday())
        end_of_week = start_of_week + timedelta(days=5)

        days_in_week = [(start_of_week + timedelta(days=i)) for i in range(6)]
        queue_data = {
            'cashier': {day: 0 for day in days_in_week},
            'registrar': {day: 0 for day in days_in_week},
            'assessment': {day: 0 for day in days_in_week},
        }

        queues = Transactions.objects.filter(
            created_at__date__range=[start_of_week, end_of_week]
        ).annotate(day=TruncDate('created_at')).values('day', 'window__name').annotate(
            count=Count('id')
        ).order_by('day')

        for queue in queues:
            window_name = queue['window__name'].lower()
            if window_name in queue_data:
                queue_data[window_name][queue['day']] = queue['count']

        labels = [day.strftime('%A') for day in days_in_week]
        data = {
            'cashier': [queue_data['cashier'][day] for day in days_in_week],
            'registrar': [queue_data['registrar'][day] for day in days_in_week],
            'assessment': [queue_data['assessment'][day] for day in days_in_week],
        }

        return JsonResponse({'success': True, 'labels': labels, 'data': data})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@role_required("STAFF")
def get_weekly_window_queues(request):
    try:
        today = datetime.now().date()
        start_of_week = today - timedelta(days=today.weekday())
        end_of_week = start_of_week + timedelta(days=5)
        window = WindowList.objects.get(id=request.user.window_id)
        queues = Transactions.objects.filter(
            created_at__date__range=[start_of_week, end_of_week], window=window
        ).annotate(day=TruncDate('created_at')).values('day').annotate(
            count=Count('id')
        ).order_by('day')

        days_in_week = [(start_of_week + timedelta(days=i)) for i in range(6)]
        queue_data = {day: 0 for day in days_in_week}

        for queue in queues:
            queue_data[queue['day']] = queue['count']

        labels = [day.strftime('%A') for day in days_in_week]
        data = [queue_data[day] for day in days_in_week]

        return JsonResponse({'success': True, 'labels': labels, 'data': data})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

def get_analytics_data(request):
    try:
        current_date = datetime.now()
        current_month = current_date.month
        current_year = current_date.year
        previous_year = current_year - 1

        num_days_in_month = (datetime(current_year, current_month % 12 + 1, 1) - timedelta(days=1)).day
        all_days = [
            datetime(current_year, current_month, day).strftime('%Y-%m-%d')
            for day in range(1, num_days_in_month + 1)
        ]
        label_days = [
            datetime(current_year, current_month, day).strftime('%d')
            for day in range(1, num_days_in_month + 1)
        ]
        current_month_data = (
            Transactions.objects.filter(created_at__year=current_year, created_at__month=current_month)
            .annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(total=Count('id'))
        )
        current_data_dict = {entry['day'].strftime('%Y-%m-%d'): entry['total'] for entry in current_month_data}

        previous_year_data = (
            Transactions.objects.filter(created_at__year=previous_year, created_at__month=current_month)
            .annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(total=Count('id'))
        )
        previous_data_dict = {entry['day'].strftime('%Y-%m-%d'): entry['total'] for entry in previous_year_data}

        current_data = [current_data_dict.get(day, 0) for day in all_days]
        previous_data = [previous_data_dict.get(day, 0) for day in all_days]

        return JsonResponse({
            'success': True,
            'labels': label_days,
            'current_data': current_data,
            'previous_data': previous_data,
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

def get_analytics_data_per_window(request):
    try:
        current_date = datetime.now()
        current_month = current_date.month
        current_year = current_date.year
        previous_year = current_year - 1
        window = WindowList.objects.get(id=request.user.window_id)

        num_days_in_month = (datetime(current_year, current_month % 12 + 1, 1) - timedelta(days=1)).day
        all_days = [
            datetime(current_year, current_month, day).strftime('%Y-%m-%d')
            for day in range(1, num_days_in_month + 1)
        ]
        label_days = [
            datetime(current_year, current_month, day).strftime('%d')
            for day in range(1, num_days_in_month + 1)
        ]
        current_month_data = (
            Transactions.objects.filter(created_at__year=current_year, created_at__month=current_month, window=window)
            .annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(total=Count('id'))
        )
        current_data_dict = {entry['day'].strftime('%Y-%m-%d'): entry['total'] for entry in current_month_data}

        previous_year_data = (
            Transactions.objects.filter(created_at__year=previous_year, created_at__month=current_month, window=window)
            .annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(total=Count('id'))
        )
        previous_data_dict = {entry['day'].strftime('%Y-%m-%d'): entry['total'] for entry in previous_year_data}

        current_data = [current_data_dict.get(day, 0) for day in all_days]
        previous_data = [previous_data_dict.get(day, 0) for day in all_days]

        return JsonResponse({
            'success': True,
            'labels': label_days,
            'current_data': current_data,
            'previous_data': previous_data,
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})