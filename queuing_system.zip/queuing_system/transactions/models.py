from django.db import models
from users.models import WindowList
# Create your models here.
class Transactions(models.Model):
    window          = models.ForeignKey(WindowList, on_delete=models.CASCADE)
    queue_number    = models.CharField(max_length=100)
    status          = models.SmallIntegerField()
    window_num      = models.SmallIntegerField()
    created_at      = models.DateTimeField(auto_now=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'transactions'