from django.urls import path
from .views import *

urlpatterns = [
    path('queue/add', add_queue, name='add_queue'),
    path('queue/next-serve', next_serve, name='next_serve'),
    path('queue/cancel-queue/', cancel_queue, name='cancel_queue'),
    path('queue/requeue', transfer_queue, name='transfer_queue'),
    path('queue/weekly-queue', get_weekly_queues, name='get_weekly_queues'),
    path('queue/weekly-window-queue', get_weekly_window_queues, name='get_weekly_window_queues'),
    path('queue/analytics/data', get_analytics_data, name='analytics_data'),
    path('queue/analytics/window-data', get_analytics_data_per_window, name='window_analytics_data'),
]