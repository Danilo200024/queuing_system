from django.urls import path
from . import consumers

websocket_urlpatterns = [
    path('ws/queues/', consumers.QueueConsumer.as_asgi()),
]
