from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import JsonResponse
from django.db.models import F
from users.decorators import redirect_if_authenticated
from users.models import Staff, WindowList
from transactions.models import Transactions
# Create your views here.
def index(request):
    return render(request, 'index.html', {})

def screen(request):
    window_mappings = {
        'Cashier': [1, 3, 5],
        'Assessment': [2, 4, 6],
        'Registrar': [7, 8, 9],
    }
    windows = WindowList.objects.all()

    served_queues = {}

    for window in windows:
        assigned_window_nums = window_mappings.get(window.name, [])
        if window.name not in served_queues:
            served_queues[window.name] = {}
        for window_num in assigned_window_nums:

            current_transaction = Transactions.objects.filter(
                window=window,
                window_num=window_num,
                status=1
            ).values(
                'queue_number',
                'window_num',
                window_name=F('window__name')
            ).order_by('-created_at').first()

            served_queues[window.name][window_num] = {
                'window_id': window.id,
                'window_name': window.name,
                'window_num': window_num,
                'queue_number': current_transaction['queue_number'] if current_transaction else None
            }

    return render(request, 'screen.html', {"queues": served_queues})

@redirect_if_authenticated
def login_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        next_url = request.POST.get('next')
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            if next_url:
                return JsonResponse({'success': True, 'next': next_url})
            else:
                role_redirect = {
                    'ADMIN': '/admin/dashboard',
                    'STAFF': '/staff/dashboard',
                }
                return JsonResponse({'success': True, 'redirect_url': role_redirect.get(user.role)})
        else:
            return JsonResponse({'success': False, 'error': 'Invalid email or password'})    
    return render(request, 'login.html', {})