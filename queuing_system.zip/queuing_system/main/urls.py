from django.urls import path
from .views import *

urlpatterns = [
    path('queue/number', index, name='index'),
    path('screen', screen, name='screen'),
    path('', login_view, name='login'),
]