from django.shortcuts import render, get_object_or_404
from django.http import Http404
from django.db.models import Count, F, Q
from django.db.models.functions import TruncDay
from users.decorators import role_required
from users.models import Staff, WindowList
from transactions.models import Transactions
from django.utils import timezone
from datetime import datetime, timedelta

import random

# Create your views here.
@role_required("ADMIN")
def admin_dashboard(request):
    today = timezone.now().date()
    total_queues = Transactions.objects.filter(
        created_at__date=today
    ).aggregate(
        on_queue=Count('id', filter=Q(status=0)),
        pending=Count('id', filter=Q(status=1)),
        completed=Count('id', filter=Q(status=2))
    )
    queue_data = {
        'on_queue': total_queues['on_queue'],
        'pending': total_queues['pending'],
        'completed': total_queues['completed']
    }
    
    context = {
        'queue_data': queue_data,
    }
    return render(request, 'admin/index.html', context)

@role_required("ADMIN")
def queue_view(request):
    queues = (
        Transactions.objects.values('window')
        .annotate(
            on_queue=Count('id', filter=Q(status=0)),
            pending=Count('id', filter=Q(status=1)),
            completed=Count('id', filter=Q(status=2))
        )
    )
    queue_data = []
    for queue in queues:
        window = WindowList.objects.get(id=queue['window'])
        queue_data.append({
            'window_name': window.name,
            'on_queue': queue['on_queue'],
            'pending': queue['pending'],
            'completed': queue['completed']
        })
    return render(request, 'admin/modules/queues.html', {"queue_data": queue_data})

@role_required('ADMIN')
def users_view(request):
    windows = WindowList.objects.all()
    users = Staff.staff.all()
    context = {'users': users, 'windows': windows}
    return render(request, 'admin/modules/users.html', context)

@role_required('ADMIN')
def admin_profile(request):
    return render(request, 'admin/modules/profile.html', {})

@role_required("STAFF")
def staff_dashboard(request):
    if not request.user.window_id:
        raise Http404("Window not assigned to the user.")

    window = get_object_or_404(WindowList, id=request.user.window_id)
    current_date = timezone.now()
    today = current_date.date()

    total_queues = Transactions.objects.filter(
        created_at__date=today, window=window
    ).aggregate(
        on_queue=Count('id', filter=Q(status=0)),
        pending=Count('id', filter=Q(status=1)),
        completed=Count('id', filter=Q(status=2))
    )
    queue_data = {
        'on_queue': total_queues['on_queue'],
        'pending': total_queues['pending'],
        'completed': total_queues['completed']
    }
    start_date = current_date - timedelta(days=30)
    historical_data = (
        Transactions.objects.filter(created_at__date__range=[start_date, today], window=window)
        .annotate(day=TruncDay('created_at'))
        .values('day')
        .annotate(total=Count('id'))
        .order_by('day')
    )
    historical_dict = {entry['day'].strftime('%Y-%m-%d'): entry['total'] for entry in historical_data}
    all_days = [
        (start_date + timedelta(days=i)).strftime('%Y-%m-%d')
        for i in range((today - start_date.date()).days + 1)
    ]
    daily_totals = [historical_dict.get(day, 0) for day in all_days]
    if not daily_totals or sum(daily_totals) == 0:
            prediction = random.randint(200, 300)
    else:
        window_size = 7
        prediction = (
            sum(daily_totals[-window_size:]) // window_size
            if len(daily_totals) >= window_size
            else sum(daily_totals) // len(daily_totals)
        )

    context = {
        'queue_data': queue_data,
        'prediction': prediction,
    }
    return render(request, 'staff/index.html', context)

@role_required('STAFF')
def staff_profile(request):
    return render(request, 'staff/modules/profile.html', {})

@role_required("STAFF")
def staff_queue_view(request):
    if not request.user.window_id:
        raise Http404("Window not assigned to the user.")

    window = get_object_or_404(WindowList, id=request.user.window_id)
    windows = WindowList.objects.all()
    on_serve = Transactions.objects.filter(
        status=1, 
        window_num=request.user.window_num, 
        window=window
    ).order_by('-created_at').first()
    context = {'on_serve': on_serve, 'windows' : windows}
    return render(request, 'staff/modules/queues.html', context)