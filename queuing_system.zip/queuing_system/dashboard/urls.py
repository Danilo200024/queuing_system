from django.urls import path
from .views import *

urlpatterns = [
    path('admin/dashboard', admin_dashboard, name='admin_dashboard'),
    path('admin/queues', queue_view, name='admin_queue_list'),
    path('admin/users', users_view, name='admin_users'),
    path('admin/profile/', admin_profile, name='admin_profile'),
    path('staff/dashboard', staff_dashboard, name='staff_dashboard'),
    path('staff/profile/', staff_profile, name='staff_profile'),
    path('staff/queues', staff_queue_view, name='staff_queues'),
]